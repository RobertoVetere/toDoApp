package com.holidevs.recyclerviewpruebas2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterData extends RecyclerView.Adapter<AdapterData.ViewHolderTask> {

    ArrayList<Task> listDatos;

    public AdapterData(ArrayList<Task> listDatos) {
        this.listDatos = listDatos;
    }

    @NonNull
    @Override
    public ViewHolderTask onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,null,false);
        return new ViewHolderTask(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderTask holder, int position) {
        Task task = listDatos.get(position);
        holder.asignarDatos(task);
    }

    @Override
    public int getItemCount() {
        return listDatos.size();
    }

    public class ViewHolderTask extends RecyclerView.ViewHolder {

        private EditText title;

        private EditText date;

        private Button btnDeleteTask;

        private CheckBox checkTask;

        public ViewHolderTask(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.txt_task);
            date = itemView.findViewById(R.id.txt_date);
            btnDeleteTask = itemView.findViewById(R.id.btn_delete);
            checkTask = itemView.findViewById(R.id.checkboxTask);
        }

        public void asignarDatos(Task task) {
            title.setText(task.getTitle());
            date.setText(task.getDate());
        }
    }
}
