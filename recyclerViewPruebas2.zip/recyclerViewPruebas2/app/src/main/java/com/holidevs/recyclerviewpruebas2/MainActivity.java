package com.holidevs.recyclerviewpruebas2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Task> listDatos;

    RecyclerView recycler;

    private Button btn_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
        setListeners();

        recycler = findViewById(R.id.recyclerID);
        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        listDatos = new ArrayList<Task>();

        for (int i = 0; i < 100; i++) {
            Task task = new Task("Tarea #" + i, "Fecha #" + i);
            listDatos.add(task);
        }

        AdapterData adapter = new AdapterData(listDatos);
        recycler.setAdapter(adapter);

    }

    private void initComponents() {
        btn_add = findViewById(R.id.btn_add);
    }

    private void setListeners() {
        btn_add.setOnClickListener(V -> {
            goToAddTask();
        });
    }

    private void goToAddTask() {
        Intent intent = new Intent(this, SetNewTaskActivity.class);
        startActivity(intent);
    }
}