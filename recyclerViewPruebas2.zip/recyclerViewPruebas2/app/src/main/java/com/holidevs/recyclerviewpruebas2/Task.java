package com.holidevs.recyclerviewpruebas2;

import java.util.ArrayList;
import java.util.Date;

public class Task {
    private String title;
    private String date;
    private Boolean check = false;

    public ArrayList<Task> tasks;

    public Task(String title, String date) {
        this.title = title;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setCheck(Boolean check) {
        this.check = check;
    }

    @Override
    public String toString() {
        return "Task{" +
                "title='" + title + '\'' +
                ", date='" + date + '\'' +
                ", check=" + check +
                '}';
    }
}

