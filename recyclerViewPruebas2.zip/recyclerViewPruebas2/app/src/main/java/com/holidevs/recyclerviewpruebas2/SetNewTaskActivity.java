package com.holidevs.recyclerviewpruebas2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class SetNewTaskActivity extends AppCompatActivity {

    private Button add_task_button;

    private EditText title_edit_text;

    private EditText date_edit_text;

    public ArrayList<Task> tasks;

    private RecyclerView recycler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_new_task);

        tasks = new ArrayList<>();

        initComponents();
        setListners();

    }

    private void initComponents() {
        date_edit_text = findViewById(R.id.date_edit_text);
        title_edit_text = findViewById(R.id.title_edit_text);
        add_task_button = findViewById(R.id.add_task_button);
    }

    private void setListners() {
        add_task_button.setOnClickListener(V -> {
            addTask();
        });
    }

    public void addTask() {
        String title = title_edit_text.getText().toString();
        String date = date_edit_text.getText().toString();


        Task task = new Task(title, date);
        tasks.add(task);
        title_edit_text.setText("");
        date_edit_text.setText("");
        Toast.makeText(this, "Tarea añadida", Toast.LENGTH_SHORT).show();
        System.out.println(task.toString());
        Log.i("taskAdd", "Task Added");

        setRecyclerView();
    }

    private void setRecyclerView() {

        recycler = findViewById(R.id.recyclerID);
        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        AdapterData adapter = new AdapterData(tasks);
        recycler.setAdapter(adapter);
    }





}